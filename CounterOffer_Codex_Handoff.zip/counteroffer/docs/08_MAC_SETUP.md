# 08. Mac, account and tunnel setup runbook

This runbook mixes existing external commands with application commands Codex must implement. They are labelled separately. Do not run a command for a nonexistent script and then mark the setup complete.

## A. Non-destructive checks (available commands)

```bash
uname -m
sw_vers
python3.12 --version
node --version
npm --version
aws --version
docker version
docker compose version
```

Expected CPU architecture is arm64. Record actual macOS, Docker engine and tool versions. The application does not load a local LLM. Runtime memory/architecture compatibility still depends on the real vendor distribution, not merely 32 GB RAM.

Use a project virtual environment and compatible Node LTS for the chosen frontend tools. Install missing software using its official supported installer/package; do not silently upgrade every system dependency. Docker provides an Apple Silicon build, but each runtime image must still support the host or a tested emulation path. [S17](12_SOURCES_AND_VERIFICATION.md)

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

After Codex resolves compatible dependencies, it creates a reproducible lockfile. Do not manufacture version pins without installation/testing.

## B. Credential files (local configuration)

Copy the examples in config to local untracked files only if those files do not already exist. Generate fresh random signing/session/upstream secrets locally. chmod secret-bearing files to 600. Never output their values in Codex responses or logs.

- `.env.app`: AWS profile/region/model; runtime ingress settings; context-signing key; public origin; session settings.
- `.env.connector`: confirmed development shop credentials/API version; upstream MCP bearer token; context-verification key; database path.
- `.env.runtime.local`: vendor-specific settings, populated from actual instructions; upstream credential.

The same context key is configured only in app and connector. The upstream bearer token is configured only in runtime and connector. The frontend build has no secret environment variables. Do not use a single dotenv loader that exposes all three files to every process.

## C. AWS/Bedrock (available commands)

Reuse a suitable existing profile. Otherwise configure SSO with the account owner's values:

```bash
aws configure sso --profile counteroffer
aws sso login --profile counteroffer
aws sts get-caller-identity --profile counteroffer --no-cli-pager
```

SSO authentication and SDK profile support are documented AWS workflows. STS identity success does not establish model access. [S14](12_SOURCES_AND_VERIFICATION.md)

Select a real supported model/inference profile in the intended region and record its ID privately as nonsecret configuration. Scope permissions to the selected model/profile as required. Account-side provider/marketplace prerequisites must be satisfied. Do not default to root credentials or ask for long-lived keys.

Codex implements `scripts/check_bedrock.py`: text request, structured tool request, dummy safe result, final answer, then streaming round trip. It must redact AWS identity fields from public artifacts and distinguish AccessDenied, region/model mismatch and throttling. The CLI does not stream ConverseStream; use the Python SDK for that test. [S13](12_SOURCES_AND_VERIFICATION.md)

## D. Shopify

Create/install the app in the same organisation as the development store, use the minimal scopes in doc 04, seed the five products manually, and confirm store currency. The user types the credentials into .env.connector, not the conversation.

Codex implements `scripts/check_shopify.py --read-only` first: acquire token without printing it, query shop/currency/catalogue, confirm unique SKUs and exact API-version response. Writing a synthetic quotation requires an explicit flag and confirmed dev-shop configuration. The account-side creation and consent steps cannot be faked by local code.

## E. Runtime and private networking

Obtain the organiser package. Inspect image architecture, dependencies and ports. Start it using its actual instructions, register it and discover its MCP ingress. No container image or provisioning command in this pack is a vendor installation recipe.

Codex implements a quote-tools container using a native-compatible Python base image and a private named Docker network. Attach the actual runtime service to that network using the supported deployment mechanism. The upstream URL is quote-tools:8100 only after shared-network resolution is verified.

A local diagnostic port mapping, when temporarily needed, must be `127.0.0.1:<port>:8100` and removed before exposing the public website. Never map upstream tools on `0.0.0.0` or create a public tunnel for them. Retain bearer and context validation during diagnostics.

Reserve app port 8000, owner port 8001, example runtime MCP port 8082, and tool internal port 8100. The vendor's other ports may differ; inspect conflicts before binding. No localhost assumption from inside containers.

## F. Commands Codex must create

```text
make doctor             # Read-only environment/config/dependency checks
make bootstrap          # Install locked project dependencies; no account writes
make tools              # Start private MCP/connector using local secrets
make app                # Run native public API and bounded worker
make owner              # Loopback-only owner evidence UI
make frontend-build     # Build static production assets
make test               # Unit/contract/integration tests without live writes
make test-live          # Explicit opt-in live checks, separate markers
make stop               # Graceful stop; preserve records and evidence
```

Do not implement `make up` that starts guessed runtime images. The runtime start/stop step remains an explicit verified vendor command or a user-supplied script after phase 0.

## G. Expose the phone website last

After authentication, secure-cookie/proxy configuration and endpoint isolation pass, start an authenticated tunnel to only port 8000. A common ngrok command after installation/login is:

```bash
ngrok http 8000
```

Set PUBLIC_ORIGIN to the exact issued HTTPS origin, restart the app safely, and verify session creation/CSRF. Do not use wildcard CORS/Host to hide a configuration problem. ngrok free HTML traffic may show a browser warning page; rehearse it. [S21](12_SOURCES_AND_VERIFICATION.md)

Cloudflare Quick Tunnels do not support SSE. Use a configured tunnel that passes streaming tests or enable the documented polling fallback. Do not spend the demo debugging a buffering tunnel. [S19](12_SOURCES_AND_VERIFICATION.md)

Before display: keep the Mac powered/awake, authenticate AWS SSO, verify fresh Shopify token renewal, run an allow/deny smoke pair and open the URL on cellular as well as venue Wi-Fi when possible. No fully offline claim: Bedrock, Shopify, tunnel and runtime portal needs are external dependencies.

## H. Cleanup

Stop the tunnel first. Revoke demo sessions/invites, stop application processes, retain evidence. Delete only explicitly identified tagged development drafts with owner confirmation; no automatic broad store cleanup. Do not delete .env files or databases as a normal restart procedure.
