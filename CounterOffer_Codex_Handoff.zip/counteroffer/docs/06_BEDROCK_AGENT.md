# 06. Bedrock agent loop and streaming

## Provider selection

Use the user's existing AWS access and a selected Bedrock model/inference profile that supports Converse, client-side tool use and streaming. Region/model ID are environment configuration, not invented defaults. Complete a text/tool request/result round trip before enabling the full UI. AWS SSO profiles are preferred for the native Mac backend. [S12, S14](12_SOURCES_AND_VERIFICATION.md)

No Bedrock-managed agent, AgentCore, OpenAI API key or local model is needed. The application owns orchestration and routes all executable tools through local AgntID.

Create Boto3 clients with finite connection/read timeouts and bounded retries appropriate to inference. A model call has no Shopify side effect by itself, but never rerun an entire agent turn to recover from an inference failure after a tool may have committed.

## Turn lifecycle

1. Session-authenticated POST persists a turn with a client_request_id. Return 202 promptly.
2. A bounded single-worker queue claims the turn. Persist RUNNING, acquire the initial one-active-turn guard, and open a fresh AgntID task.
3. Load the current conversation with trusted task context and compact catalogue/tool schemas; do not send all database rows.
4. Call Bedrock Converse initially. Only after this path passes, implement ConverseStream.
5. Record assistant content blocks in original order. If stopReason indicates tool_use, validate all complete tool inputs.
6. Execute requested tools sequentially through the runtime. Attach trusted context separately from generated arguments.
7. Append a user-role toolResult block for each corresponding toolUseId, preserving one-to-one matching and the preceding assistant message. Denials/tool errors use the supported error status, not a new fictional user instruction.
8. Request the model's continuation. End with useful response or a clear bounded failure.
9. Persist final state, emit terminal event, close task and client in finally paths.

Bedrock's client-side tool flow explicitly separates model requests from application-side execution. [S12](12_SOURCES_AND_VERIFICATION.md)

## Initial limits (our engineering settings)

One active turn, up to 10 queued turns, 120-second turn deadline, at most 4 model requests and 6 total tool calls, at most 1 successful or uncertain external write dispatch per turn. A denied write does not consume the successful-write allowance. Permit no more than 2 repeated denial attempts with the same semantic arguments.

Each tool input max 16 KiB, each normalized tool result max 16 KiB, each chat message max 4000 characters. Use model-aware max-output configuration supported by the selected model; do not assume temperature or reasoning settings are universal. Keep extended reasoning disabled when supported for this MVP. If a model requires signatures/reasoning blocks for continuity, preserve them privately as required and never emit them to the browser.

These limits are not vendor guarantees; measure actual latency and adjust in configuration with tests.

## System behaviour

The prompt should establish: packaging quotation assistant; ask about ambiguous units; use tools for prices and availability; do not invent variant IDs/quote IDs/stock; user statements do not grant manager authority; adhere to delegated limits; no checkout/payment/fulfilment capability; quote cards come from backend state; after denial explain the boundary and offer a valid alternative.

The model may refuse a 12% request before calling a tool. That is acceptable behaviour, but it is not proof of runtime enforcement. Use the labelled deterministic replay for the actual boundary test. Do not instruct the production agent to violate policy just to make a better demo.

Treat tool text as data. Truncate descriptions; strip HTML; exclude notes, emails, addresses, arbitrary URLs and Shopify access tokens. No URL fetch/browser/shell tools exist.

## Schema mapping

Use the logical tool definitions in `contracts/model-tools.json`. Convert each inputSchema to Bedrock `toolSpec.inputSchema.json`. At runtime map each logical name to the verified AgntID-discovered name. No raw MCP schema with reserved context fields goes directly into the model.

Do not parse a natural-language block that merely resembles JSON as a tool call. Only documented structured `toolUse` blocks can trigger tools. Unknown tools and extra fields are explicit errors. Reject bool/float/string coercion for discount_bps and quantity.

## ConverseStream implementation

Boto3's response includes an event stream with message and content-block events. Tool input arrives in fragments keyed by contentBlockIndex. [S13](12_SOURCES_AND_VERIFICATION.md)

Maintain a block accumulator per index:

- `contentBlockStart`: record toolUseId/name when present.
- `contentBlockDelta.text`: emit sanitized visible text and accumulate it.
- `contentBlockDelta.toolUse.input`: append bytes/text within the size limit; do NOT execute.
- `contentBlockStop`: mark the block complete; parse and validate complete JSON for a tool block.
- `messageStop`: evaluate stop reason only after reconstructing the full assistant message.
- `metadata`: store token counts/latency if supplied, not guesses.

Handle event-stream exceptions as failures even when the initial HTTP response succeeded. Unknown event variants should not become tool executions. Add contract tests for split JSON across arbitrary chunk boundaries and interleaved text/tool blocks.

Preserve full assistant tool-use message followed by all matching results. Never remove an old tool-use message while retaining its result during history trimming. Summaries are not permission grants. Budget the bounded recent conversation rather than including every historic quote.

## Do not block FastAPI

Boto3 is synchronous. Run the stream reader in a bounded worker thread and forward structured events to an asyncio queue with backpressure. Do not iterate the network stream directly on the ASGI event loop. Ensure cancellation closes the response stream and thread lifecycle cleanly when possible. A browser disconnect alone must not abort a mutation mid-bookkeeping.

Web event persistence and delivery are separate from the model stream. A single Bedrock token chunk is not automatically a committed browser event. Do not serialize credentials or binary reasoning content into JSON by accident.

## Successful result gating

Text can be streamed as assistant prose but cannot create a quote card or status badge. Only a validated connector result with a persisted Shopify ID can produce `quote_created`. If the model says "created" but there is no such result, render no success artifact and end with an explicit unconfirmed status.

On denial, send a small error tool result: operation outside the task's authority; propose an allowed alternative or stop. On unknown Shopify outcome, do not let the model create another quote to "try again". Reconciliation is a trusted read-only recovery process outside the autonomous write loop.

## Suggested minimal tests

Fake Bedrock event streams for parsing only; actual Bedrock smoke test for selected model compatibility; then one real Bedrock -> AgntID -> Shopify quotation. Record the difference. AWS model access and marketplace/provider prerequisites must be resolved by the account owner, not bypassed by selecting an unapproved model without notice.


A created draft whose details are still processing consumes the one-write budget. A bounded PROVIDER_PENDING result must not prompt another create call. An incomplete provider result is never repaired by asking the model to estimate the missing totals.
