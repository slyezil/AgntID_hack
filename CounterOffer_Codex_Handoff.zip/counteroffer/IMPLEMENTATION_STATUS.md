# Implementation status

This file begins as a status template. Only the documentation pack and its local validation exist. Codex must replace NOT STARTED with evidence from the Mac.

| Phase | Status | Evidence / actual command | Blocker |
|---|---|---|---|
| 0. Environment and capability discovery | NOT STARTED | None | Runtime/account checks pending |
| 1. Domain and fixed Shopify connector | NOT STARTED | None | Dev-store installation pending |
| 2. Private MCP service | NOT STARTED | None | Dependency selection pending |
| 3. Real AgntID allow/deny | NOT STARTED | None | Runtime/policy access pending |
| 4. Bedrock agent and persistent turns | NOT STARTED | None | Model/region selection pending |
| 5. Mobile website and owner evidence | NOT STARTED | None | Backend gates pending |
| 6. Hardening, tunnel and full proof | NOT STARTED | None | Earlier gates pending |

## Capability ledger

Record without secrets: macOS version, CPU architecture, Python/Node/Docker versions, locked dependencies, runtime version/image digest/architecture, MCP protocol, SDK public signatures, runtime authentication method, tool names as discovered, policy versions, Shopify store domain and confirmed environment, returned API version, Bedrock region/model/inference profile.

## Actual test runs

Add date, git commit, test command, pass/fail/skipped counts, provider mode, evidence paths and unresolved findings. A test-double run never counts as live AgntID or Shopify proof.

## Decision log

Record deviations with reason, verified source, security consequence, affected contracts and tests. Do not silently alter this specification.
